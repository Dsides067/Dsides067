module.exports = (client, olds, news) => {
  require("../handlers/voiceStateUpdateCommands")(client, olds, news);
};
