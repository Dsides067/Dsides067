module.exports = (client, role) => {
  require("../handlers/roleCreateCommands")(client, role);
};
