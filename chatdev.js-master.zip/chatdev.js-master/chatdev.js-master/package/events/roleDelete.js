module.exports = (client, role) => {
  require("../handlers/roleDeleteCommands")(client, role);
};
