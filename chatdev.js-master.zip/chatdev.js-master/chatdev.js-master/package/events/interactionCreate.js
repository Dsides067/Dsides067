module.exports = (client, interaction) => {
  require("../handlers/interactionCommands")(client, interaction);
};
