module.exports = (client, channel, user) => {};
