module.exports = (client, oldc, newc) => {
  require("../handlers/channelUpdateCommands")(client, oldc, newc);
};
