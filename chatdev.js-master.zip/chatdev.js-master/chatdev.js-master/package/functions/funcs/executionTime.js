module.exports = async (d) => {
  return {
    code: d.command.code,
  };
};
