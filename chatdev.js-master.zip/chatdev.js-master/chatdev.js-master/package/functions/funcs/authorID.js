const authorID = (d) => {
  return {
    code: d.command.code.replaceLast(
      "¶IDAuthor",
      d.message.author ? d.message.author.id : ""
    ),
  };
};

module.exports = authorID;
