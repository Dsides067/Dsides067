module.exports = async (d) => {
  const code = d.command.code;

  const r = code.split("¶setEmoji").length - 1;

  const inside = code.split("¶setEmoji")[r].after();

  const err = d.inside(inside);

  if (err) return d.error(err);

  const options = ([url, name, returnEmoji = "no", ...roleIDs] = inside.splits);

  const emoji = await d.message.guild.emojis
    .create(
      url.addBrackets(),
      name.addBrackets(),
      roleIDs.length
        ? {
            roles: roleIDs,
          }
        : undefined
    )
    .catch((err) => {});

  if (!emoji)
    return d.error(`:x: Impossible de créé l'emoji ! url: ${url}, nom: ${name} `);

  return {
    code: code.replaceLast(
      `¶setEmoji${inside.total}`,
      returnEmoji === "yes" ? emoji.toString() : ""
    ),
  };
};
